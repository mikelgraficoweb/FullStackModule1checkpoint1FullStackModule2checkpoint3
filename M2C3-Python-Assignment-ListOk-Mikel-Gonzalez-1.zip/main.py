# exercise 1
string = "this is a string"
list = ['SCSS', 'javascript', 'python', 'REACT']
number = 4
guide_completed = True

print(string)
print(list)
print(number)
print(guide_completed)

# exercise 2
#three_letters = string[0:3]
#print(three_letters)
query_string = string.index('thi') 
print(query_string)

# exercise 3
first_list= list.index('python') 
print(first_list)

# exercise 4
new_number = number + 10
print(new_number)

# exercise 5
last_list= list.index('javascript') 
print(last_list)

# exercise 6
names = 'harry,alex,susie,jared,gail,conner'
list_of_names = names.split(',')
print(list_of_names)

# exercise 7
first_word = string[:4]
print(first_word.upper())

low_string = string[4:]
#print(low_string.lower())

mix_string = (first_word.upper()) + (low_string.lower())
print(mix_string)

# exercise 8
str_interp = f'2+2 normally gives a result of {number}'
print(str_interp) 

# exercise 9
str_hello = "hello world"
print(str_hello)

# exercise extra 
str_hola = "Hola"
print(str_hola)
query = str_hola.index("Hola")
str_adios = str_hola.replace("Hola", "adiós")
print(str_adios)